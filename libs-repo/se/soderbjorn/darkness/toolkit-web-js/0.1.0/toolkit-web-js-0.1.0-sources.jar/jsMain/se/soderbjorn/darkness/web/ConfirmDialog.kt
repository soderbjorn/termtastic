/**
 * Drop-in modal confirmation dialog.
 *
 * Generic helper that opens an overlay modal, calls the supplied confirm/
 * cancel callbacks, and tears itself down. Handles Escape-to-cancel,
 * backdrop-click-to-cancel, focus management on the confirm button, and
 * basic styling that respects the current CSS-var theme.
 *
 * Visual styles ride on the `.dt-modal*` classes shipped in
 * `darkness-toolkit.css`; consumers must call [injectDarknessToolkitStyles]
 * once at boot for the modal to render correctly.
 *
 * @see ResolvedPalette
 */
package se.soderbjorn.darkness.web

import kotlinx.browser.document
import org.w3c.dom.HTMLButtonElement
import org.w3c.dom.HTMLElement
import org.w3c.dom.events.KeyboardEvent

/**
 * Opens a modal confirmation dialog with the given message and labels.
 *
 * Closes itself when the user confirms, cancels, presses Escape, or clicks
 * the backdrop. The relevant callback is invoked in each case (only one).
 *
 * @param title         dialog title shown in the header
 * @param message       body message shown above the buttons
 * @param confirmLabel  label for the primary (confirm) button. Defaults to "OK".
 * @param cancelLabel   label for the secondary (cancel) button. Defaults to "Cancel".
 * @param destructive   if true, styles the confirm button as destructive
 *   (uses `--t-semantic-danger` for the background).
 * @param messageIsHtml if true, [message] is set as `innerHTML` so callers
 *   can include inline markup like `<strong>name</strong>`. When false
 *   (the default), [message] is rendered as plain text via `textContent`.
 *   HTML callers must escape any user-supplied substrings themselves.
 * @param onConfirm     invoked when the user confirms
 * @param onCancel      invoked when the user cancels (Escape, backdrop, or cancel button)
 */
fun showConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String = "OK",
    cancelLabel: String = "Cancel",
    destructive: Boolean = false,
    messageIsHtml: Boolean = false,
    onConfirm: () -> Unit = {},
    onCancel: () -> Unit = {},
) {
    val backdrop = document.createElement("div") as HTMLElement
    backdrop.className = "dt-modal-backdrop"

    val card = document.createElement("div") as HTMLElement
    card.className = "dt-modal"

    val titleEl = document.createElement("h2") as HTMLElement
    titleEl.className = "dt-modal-title"
    titleEl.textContent = title
    card.appendChild(titleEl)

    val messageEl = document.createElement("p") as HTMLElement
    messageEl.className = "dt-modal-message"
    if (messageIsHtml) messageEl.innerHTML = message else messageEl.textContent = message
    card.appendChild(messageEl)

    val buttons = document.createElement("div") as HTMLElement
    buttons.className = "dt-modal-buttons"

    val cancelBtn = document.createElement("button") as HTMLButtonElement
    cancelBtn.type = "button"
    cancelBtn.textContent = cancelLabel
    cancelBtn.className = "dt-modal-btn dt-modal-btn-cancel"

    val confirmBtn = document.createElement("button") as HTMLButtonElement
    confirmBtn.type = "button"
    confirmBtn.textContent = confirmLabel
    confirmBtn.className = "dt-modal-btn dt-modal-btn-confirm" +
        if (destructive) " dt-destructive" else ""

    buttons.appendChild(cancelBtn)
    buttons.appendChild(confirmBtn)
    card.appendChild(buttons)
    backdrop.appendChild(card)
    document.body?.appendChild(backdrop)
    confirmBtn.focus()

    var done = false
    fun close(action: () -> Unit) {
        if (done) return
        done = true
        backdrop.parentNode?.removeChild(backdrop)
        action()
    }

    cancelBtn.addEventListener("click", { close(onCancel) })
    confirmBtn.addEventListener("click", { close(onConfirm) })
    backdrop.addEventListener("click", { ev ->
        if (ev.target === backdrop) close(onCancel)
    })
    val keyHandler: (org.w3c.dom.events.Event) -> Unit = { ev ->
        val k = ev as KeyboardEvent
        if (k.key == "Escape") close(onCancel)
        else if (k.key == "Enter" && document.activeElement === confirmBtn) close(onConfirm)
    }
    document.addEventListener("keydown", keyHandler)
    // We don't have a clean way to remove the listener after close without
    // capturing the function reference itself; the handler is no-op once
    // `done` is set, so it's effectively dead.
}
