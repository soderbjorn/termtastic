/**
 * Per-theme editor pane: name + mode header, per-section scheme assignment
 * dropdowns, and the shared scheme-picker popover used by both the theme
 * editor rows and any consumer wanting visually-consistent scheme menus.
 */
package se.soderbjorn.darkness.web.themeeditor

import se.soderbjorn.darkness.core.*
import se.soderbjorn.darkness.web.showConfirmDialog

import kotlinx.browser.document
import kotlinx.browser.window
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.w3c.dom.HTMLElement
import org.w3c.dom.HTMLInputElement
import org.w3c.dom.HTMLSelectElement
import org.w3c.dom.events.Event

/**
 * Render the right-hand editor for the currently-selected theme. Default
 * themes show a read-only preview with a prominent "Clone to edit" button;
 * custom themes show editable name, mode, and per-section scheme rows.
 */
internal fun renderThemeEditor(
    container: HTMLElement,
    selectedName: String?,
    refresh: () -> Unit,
) {
    container.innerHTML = ""
    val state = themeManagerHost()
    val name = selectedName ?: return
    val preset = state.customThemes[name] ?: defaultThemes.firstOrNull { it.name == name }
    if (preset == null) {
        val empty = document.createElement("div") as HTMLElement
        empty.className = "dt-theme-manager-empty"
        empty.textContent = "Theme not found."
        container.appendChild(empty)
        return
    }
    val isDefault = preset.name !in state.customThemes
    isEditorDirty = false
    var syncActionsEnabled: () -> Unit = {}
    val markDirty: () -> Unit = {
        isEditorDirty = true
        syncActionsEnabled()
    }

    val header = document.createElement("div") as HTMLElement
    header.className = "dt-theme-editor-header"

    val preview = document.createElement("div") as HTMLElement
    preview.className = "dt-theme-editor-preview"
    preview.innerHTML = themeManagerHost().renderConfigSilhouetteHtml(preset)
    header.appendChild(preview)

    val info = document.createElement("div") as HTMLElement
    info.className = "dt-theme-editor-info"

    val nameLabel = document.createElement("div") as HTMLElement
    nameLabel.className = "dt-theme-editor-label"
    nameLabel.textContent = "Name"
    info.appendChild(nameLabel)

    val nameInput = document.createElement("input") as HTMLInputElement
    nameInput.className = "dt-theme-editor-input"
    nameInput.type = "text"
    nameInput.value = preset.name
    nameInput.disabled = isDefault
    nameInput.addEventListener("input", { _: Event -> markDirty() })
    info.appendChild(nameInput)

    val modeLabel = document.createElement("div") as HTMLElement
    modeLabel.className = "dt-theme-editor-label"
    modeLabel.textContent = "Optimized for"
    info.appendChild(modeLabel)

    val modeSelect = document.createElement("select") as HTMLSelectElement
    modeSelect.className = "dt-theme-editor-select"
    modeSelect.disabled = isDefault
    for (m in ConfigMode.values()) {
        val opt = document.createElement("option") as org.w3c.dom.HTMLOptionElement
        opt.value = m.name
        opt.textContent = when (m) {
            ConfigMode.Dark -> "Dark mode"
            ConfigMode.Light -> "Light mode"
            ConfigMode.Both -> "Both dark and light mode"
        }
        if (m == preset.mode) opt.selected = true
        modeSelect.appendChild(opt)
    }
    modeSelect.addEventListener("change", { _: Event -> markDirty() })
    info.appendChild(modeSelect)

    header.appendChild(info)
    container.appendChild(header)

    val sectionsWrap = document.createElement("div") as HTMLElement
    sectionsWrap.className = "dt-theme-editor-sections"

    val sectionValues = mutableMapOf<String, String>()
    sectionValues[""] = preset.colorScheme
    sectionValues["sidebar"] = preset.sidebar
    sectionValues["terminal"] = preset.terminal
    sectionValues["diff"] = preset.diff
    sectionValues["fileBrowser"] = preset.fileBrowser
    sectionValues["tabs"] = preset.tabs
    sectionValues["chrome"] = preset.chrome
    sectionValues["windows"] = preset.windows
    sectionValues["active"] = preset.active
    sectionValues["bottomBar"] = preset.bottomBar

    // Collected so the main row's onChange can re-render sibling triggers
    // whose selection is "Default" (they inherit the main's swatch).
    val rowRefreshers = mutableListOf<() -> Unit>()
    for ((key, label) in MANAGER_SECTIONS) {
        val (row, refreshRow) = buildSectionRow(
            sectionKey = key,
            sectionLabel = label,
            currentSchemeName = sectionValues[key] ?: "",
            isReadonly = isDefault,
            getMainSchemeName = { sectionValues[""] ?: "" },
        ) { newName ->
            sectionValues[key] = newName
            if (key == "") rowRefreshers.forEach { it() }
            markDirty()
        }
        rowRefreshers += refreshRow
        sectionsWrap.appendChild(row)
    }
    container.appendChild(sectionsWrap)

    val actions = document.createElement("div") as HTMLElement
    actions.className = "dt-theme-editor-actions"

    if (isDefault) {
        val cloneHint = document.createElement("div") as HTMLElement
        cloneHint.className = "dt-theme-editor-hint"
        cloneHint.textContent = "Default themes are read-only. Clone to edit."
        actions.appendChild(cloneHint)

        val cloneBtn = document.createElement("button") as HTMLElement
        cloneBtn.className = "dt-theme-editor-btn dt-primary"
        cloneBtn.textContent = "Clone to edit"
        cloneBtn.addEventListener("click", { showCloneThemePrompt(preset) })
        actions.appendChild(cloneBtn)
    } else {
        val saveBtn = document.createElement("button") as HTMLElement
        saveBtn.className = "dt-theme-editor-btn dt-primary"
        saveBtn.textContent = "Save"
        saveBtn.addEventListener("click", { _: Event ->
            val newName = nameInput.value.trim()
            if (newName.isEmpty()) return@addEventListener
            val newMode = runCatching { ConfigMode.valueOf(modeSelect.value) }.getOrDefault(ConfigMode.Both)
            val next = preset.copy(
                name = newName,
                mode = newMode,
                colorScheme = sectionValues[""] ?: preset.colorScheme,
                sidebar = sectionValues["sidebar"] ?: "",
                terminal = sectionValues["terminal"] ?: "",
                diff = sectionValues["diff"] ?: "",
                fileBrowser = sectionValues["fileBrowser"] ?: "",
                tabs = sectionValues["tabs"] ?: "",
                chrome = sectionValues["chrome"] ?: "",
                windows = sectionValues["windows"] ?: "",
                active = sectionValues["active"] ?: "",
                bottomBar = sectionValues["bottomBar"] ?: "",
            )
            GlobalScope.launch(start = CoroutineStart.UNDISPATCHED) {
                if (newName != preset.name) {
                    themeManagerHost().deleteCustomTheme(preset.name)
                }
                themeManagerHost().saveCustomTheme(next)
            }
            isEditorDirty = false
            pokeManager()
        })
        actions.appendChild(saveBtn)

        val revertBtn = document.createElement("button") as HTMLElement
        revertBtn.className = "dt-theme-editor-btn"
        revertBtn.textContent = "Revert"
        revertBtn.addEventListener("click", {
            isEditorDirty = false
            refresh()
        })
        actions.appendChild(revertBtn)

        syncActionsEnabled = {
            val clean = !isEditorDirty
            console.log("[theme-editor] syncActionsEnabled theme clean=$clean isEditorDirty=$isEditorDirty")
            saveBtn.asDynamic().disabled = clean
            revertBtn.asDynamic().disabled = clean
            saveBtn.classList.toggle("dt-disabled", clean)
            revertBtn.classList.toggle("dt-disabled", clean)
        }
        syncActionsEnabled()

        val deleteBtn = document.createElement("button") as HTMLElement
        deleteBtn.className = "dt-theme-editor-btn dt-danger"
        deleteBtn.textContent = "Delete"
        deleteBtn.addEventListener("click", {
            showConfirmDialog(
                title = "Delete theme",
                message = "Delete theme <b>${preset.name}</b>?",
                confirmLabel = "Delete",
            ) {
                GlobalScope.launch(start = CoroutineStart.UNDISPATCHED) {
                    themeManagerHost().deleteCustomTheme(preset.name)
                }
                isEditorDirty = false
                pokeManager()
            }
        })
        actions.appendChild(deleteBtn)
    }

    container.appendChild(actions)
}

/**
 * Resolve a colour-scheme name to its [ColorScheme], checking custom
 * schemes first and falling back to [recommendedColorSchemes]. Returns `null`
 * when the name is empty or unknown.
 */
internal fun resolveSchemeByName(name: String): ColorScheme? {
    if (name.isEmpty()) return null
    val state = themeManagerHost()
    return state.customSchemes[name]?.toColorScheme()
        ?: recommendedColorSchemes.firstOrNull { it.name == name }
}

/**
 * Populate [container] with the visual row content for [schemeName]: a
 * mini swatch and the scheme name. An empty [schemeName] renders the
 * "Default" (inherit from main) variant with [mainSchemeName]'s swatch so
 * the user can see what it resolves to.
 */
fun fillSchemeRowContent(
    container: HTMLElement,
    schemeName: String,
    mainSchemeName: String,
) {
    container.innerHTML = ""
    val isDefault = schemeName.isEmpty()
    val effectiveName = if (isDefault) mainSchemeName else schemeName
    val resolved = resolveSchemeByName(effectiveName)

    val swatchWrap = document.createElement("span") as HTMLElement
    swatchWrap.className = "dt-scheme-row-swatch"
    if (resolved != null) swatchWrap.innerHTML = themeManagerHost().renderThemeSwatchHtml(resolved)
    container.appendChild(swatchWrap)

    val labelWrap = document.createElement("span") as HTMLElement
    labelWrap.className = "dt-scheme-row-label" + if (isDefault) " dt-muted" else ""
    labelWrap.textContent = if (isDefault) "Default" else schemeName
    container.appendChild(labelWrap)
}

/**
 * Group scheme names for the picker dropdowns. Returns an ordered list of
 * `(headerLabel, names)` pairs — Favorites first, then Custom, then Default
 * (built-ins). Each group is alpha-sorted internally; empty groups are
 * omitted.
 *
 * @return ordered groups; callers render a header row followed by one
 *   option per name
 */
fun buildSchemeGroups(): List<Pair<String, List<String>>> {
    val state = themeManagerHost()
    val favs = state.favoriteSchemes.sorted()
    val customs = state.customSchemes.keys.sorted()
    val defaults = recommendedColorSchemes.map { it.name }.sorted()
    return buildList {
        if (favs.isNotEmpty()) add("Favorites" to favs)
        if (customs.isNotEmpty()) add("Custom" to customs)
        add("Default" to defaults)
    }
}

/**
 * Open the scheme-picker popover anchored below [anchor]. Lists every
 * recommended, custom, and favourited scheme as a rich row (swatch + name),
 * grouped under "Favorites", "Custom", and "Default" headers (in that
 * order). Non-main sections get a leading "Inherit" entry that inherits
 * from the main scheme.
 *
 * @see buildSchemeGroups for the shared grouping/ordering
 */
private fun openSectionSchemeMenu(
    anchor: HTMLElement,
    sectionKey: String,
    selected: String,
    getMainSchemeName: () -> String,
    onPick: (String) -> Unit,
) {
    document.querySelectorAll(".dt-scheme-menu").let { nl ->
        for (i in 0 until nl.length) (nl.item(i) as? HTMLElement)?.remove()
    }

    val menu = document.createElement("div") as HTMLElement
    menu.className = "dt-scheme-menu"

    fun addOption(schemeName: String) {
        val item = document.createElement("button") as HTMLElement
        item.className = "dt-scheme-menu-option" + if (schemeName == selected) " dt-selected" else ""
        item.setAttribute("type", "button")
        val inner = document.createElement("span") as HTMLElement
        inner.className = "dt-scheme-menu-option-content"
        fillSchemeRowContent(inner, schemeName, getMainSchemeName())
        item.appendChild(inner)
        item.addEventListener("click", { ev: Event ->
            ev.stopPropagation()
            menu.remove()
            onPick(schemeName)
        })
        menu.appendChild(item)
    }

    fun addHeader(text: String) {
        val h = document.createElement("div") as HTMLElement
        h.className = "dt-scheme-menu-header"
        h.textContent = text
        menu.appendChild(h)
    }

    if (sectionKey.isNotEmpty()) {
        addHeader("Inherit")
        addOption("")
    }

    for ((header, names) in buildSchemeGroups()) {
        addHeader(header)
        for (n in names) addOption(n)
    }

    val rect = anchor.getBoundingClientRect()
    menu.style.position = "fixed"
    menu.style.left = "${rect.left}px"
    menu.style.top = "${rect.bottom + 4}px"
    menu.style.minWidth = "${rect.width}px"
    document.body?.appendChild(menu)

    val viewportH = window.innerHeight
    val menuH = menu.getBoundingClientRect().height
    if (rect.bottom + 4 + menuH > viewportH - 8) {
        val above = rect.top - menuH - 4
        if (above >= 8) {
            menu.style.top = "${above}px"
        } else {
            menu.style.maxHeight = "${(viewportH - rect.bottom - 12).coerceAtLeast(120.0)}px"
        }
    }

    val dismiss = { _: Event -> menu.remove() }
    document.addEventListener("click", dismiss, js("({once:true})"))
}

/**
 * Build a single "label + scheme picker" row for the theme editor. Returns
 * the row element paired with a `refresh` lambda the caller can invoke when
 * the main scheme changes — sibling rows whose selection is "Default" can
 * then re-render their inherited swatch without the full editor re-rendering.
 *
 * @param getMainSchemeName lazy accessor for the preset's main scheme,
 *   consulted both at refresh time and at menu-open time so the
 *   "Default" option always shows the current main's swatch.
 */
private fun buildSectionRow(
    sectionKey: String,
    sectionLabel: String,
    currentSchemeName: String,
    isReadonly: Boolean,
    getMainSchemeName: () -> String,
    onChange: (String) -> Unit,
): Pair<HTMLElement, () -> Unit> {
    val row = document.createElement("div") as HTMLElement
    row.className = "dt-theme-editor-section-row"

    val label = document.createElement("div") as HTMLElement
    label.className = "dt-theme-editor-section-label"
    label.textContent = sectionLabel
    row.appendChild(label)

    val trigger = document.createElement("button") as HTMLElement
    trigger.className = "dt-scheme-picker"
    trigger.setAttribute("type", "button")
    trigger.asDynamic().disabled = isReadonly

    val content = document.createElement("span") as HTMLElement
    content.className = "dt-scheme-picker-content"
    trigger.appendChild(content)

    val chevron = document.createElement("span") as HTMLElement
    chevron.className = "dt-scheme-picker-chevron"
    chevron.textContent = "▾"
    trigger.appendChild(chevron)

    var selected = currentSchemeName
    val refreshTrigger = {
        fillSchemeRowContent(content, selected, getMainSchemeName())
    }
    refreshTrigger()

    trigger.addEventListener("click", { ev: Event ->
        ev.stopPropagation()
        if (isReadonly) return@addEventListener
        openSectionSchemeMenu(
            anchor = trigger,
            sectionKey = sectionKey,
            selected = selected,
            getMainSchemeName = getMainSchemeName,
        ) { picked ->
            if (picked != selected) {
                selected = picked
                refreshTrigger()
                onChange(picked)
            }
        }
    })

    row.appendChild(trigger)
    return row to refreshTrigger
}
