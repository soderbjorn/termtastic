/**
 * Drop-in top-bar component for the toolkit's app shell.
 *
 * Renders a horizontal strip with a logo / title slot on the left, a
 * tab strip in the middle, and an actions slot on the right. Apps wire
 * up the slots; the toolkit only owns the layout and theming.
 *
 * Visual styles ride on the `.dt-topbar*` classes shipped in
 * `darkness-toolkit.css`; consumers must call `injectDarknessToolkitStyles()`
 * once at boot.
 *
 * @see TopBarSpec
 */
package se.soderbjorn.darkness.web.shell

import kotlinx.browser.document
import org.w3c.dom.HTMLButtonElement
import org.w3c.dom.HTMLElement

/**
 * One tab in the top bar.
 *
 * @property id         stable id used by [TopBarSpec.activeTabId] and the
 *   [TopBarSpec.onTabSelected] callback.
 * @property label      visible tab label.
 */
data class TopBarTab(
    val id: String,
    val label: String,
)

/**
 * Top-bar configuration passed to [renderTopBar].
 *
 * @property leadingContent     element shown at the far left (logo, app
 *   title). May be null for no leading content.
 * @property tabs               list of tabs; pass an empty list for no
 *   tab strip.
 * @property activeTabId        id of the currently active tab, or null.
 * @property onTabSelected      callback when a tab is clicked.
 * @property trailingContent    element shown at the far right (action
 *   buttons, menus). May be null.
 */
class TopBarSpec(
    val leadingContent: HTMLElement? = null,
    val tabs: List<TopBarTab> = emptyList(),
    val activeTabId: String? = null,
    val onTabSelected: (String) -> Unit = {},
    val trailingContent: HTMLElement? = null,
)

/**
 * Builds the top-bar element for the given [spec]. The returned element
 * is a sibling-style flex row that the host app inserts wherever it wants
 * the bar to appear.
 *
 * @param spec the top-bar specification
 * @return a fresh top-bar [HTMLElement]
 */
fun renderTopBar(spec: TopBarSpec): HTMLElement {
    val bar = document.createElement("div") as HTMLElement
    bar.className = "dt-topbar"

    val leading = document.createElement("div") as HTMLElement
    leading.className = "dt-topbar-leading"
    spec.leadingContent?.let { leading.appendChild(it) }
    bar.appendChild(leading)

    val tabStrip = document.createElement("div") as HTMLElement
    tabStrip.className = "dt-topbar-tabstrip"
    for (tab in spec.tabs) {
        val tabEl = document.createElement("button") as HTMLButtonElement
        tabEl.type = "button"
        tabEl.className = "dt-topbar-tab" +
            if (tab.id == spec.activeTabId) " dt-selected" else ""
        tabEl.setAttribute("data-tab-id", tab.id)
        tabEl.textContent = tab.label
        tabEl.addEventListener("click", { spec.onTabSelected(tab.id) })
        tabStrip.appendChild(tabEl)
    }
    bar.appendChild(tabStrip)

    val trailing = document.createElement("div") as HTMLElement
    trailing.className = "dt-topbar-trailing"
    spec.trailingContent?.let { trailing.appendChild(it) }
    bar.appendChild(trailing)

    return bar
}
