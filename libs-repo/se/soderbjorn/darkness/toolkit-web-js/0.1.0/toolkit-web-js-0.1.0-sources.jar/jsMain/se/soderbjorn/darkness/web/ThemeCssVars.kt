/**
 * Helpers for projecting a [ResolvedPalette] onto a DOM element via CSS
 * custom properties.
 *
 * This module is deliberately library-style: it ships pure functions and
 * a small `applyCssVars` helper. Apps decide *where* to apply the variables
 * (document root, a subtree, or a Shadow DOM) — there is no global "install
 * the theme on document.body" function.
 *
 * Property names follow the `--t-group-token` convention (e.g.
 * `--t-surface-base`, `--t-text-primary`) which matches the convention
 * used by termtastic's existing stylesheet so themes round-trip without
 * stylesheet rewrites.
 *
 * @see ResolvedPalette
 */
package se.soderbjorn.darkness.web

import org.w3c.dom.HTMLElement
import se.soderbjorn.darkness.core.Appearance
import se.soderbjorn.darkness.core.ResolvedPalette
import se.soderbjorn.darkness.core.argbToCss

/**
 * Returns whether the host platform currently prefers a dark colour scheme,
 * based on the browser's `prefers-color-scheme` media query.
 *
 * @return true if the system prefers dark mode
 */
fun systemPrefersDark(): Boolean =
    kotlinx.browser.window.matchMedia("(prefers-color-scheme: dark)").matches

/**
 * Resolves the [Appearance] preference into a concrete `isDark` boolean,
 * deferring to [systemPrefersDark] when the user's preference is `Auto`.
 *
 * @param appearance the user's selected appearance preference
 * @return true if the dark variant should be used
 */
fun isDarkActive(appearance: Appearance): Boolean = when (appearance) {
    Appearance.Dark -> true
    Appearance.Light -> false
    Appearance.Auto -> systemPrefersDark()
}

/**
 * Converts a [ResolvedPalette] to a map of CSS custom property names to
 * CSS colour values.
 *
 * Property names follow the `--t-group-token` convention (e.g.
 * `--t-surface-base`, `--t-text-primary`). Colours with alpha use
 * `rgba()` format; fully opaque colours use `#rrggbb`.
 *
 * @return map of CSS property name to CSS colour string
 * @see argbToCss
 * @see applyCssVars
 */
fun ResolvedPalette.toCssVarMap(): Map<String, String> = buildMap {
    // Surface
    put("--t-surface-base", argbToCss(surface.base))
    put("--t-surface-raised", argbToCss(surface.raised))
    put("--t-surface-sunken", argbToCss(surface.sunken))
    put("--t-surface-overlay", argbToCss(surface.overlay))
    // Text
    put("--t-text-primary", argbToCss(text.primary))
    put("--t-text-secondary", argbToCss(text.secondary))
    put("--t-text-tertiary", argbToCss(text.tertiary))
    put("--t-text-disabled", argbToCss(text.disabled))
    put("--t-text-inverse", argbToCss(text.inverse))
    // Border
    put("--t-border-subtle", argbToCss(border.subtle))
    put("--t-border-default", argbToCss(border.default))
    put("--t-border-strong", argbToCss(border.strong))
    put("--t-border-focus", argbToCss(border.focus))
    put("--t-border-focusGlow", argbToCss(border.focusGlow))
    // Accent
    put("--t-accent-primary", argbToCss(accent.primary))
    put("--t-accent-primarySoft", argbToCss(accent.primarySoft))
    put("--t-accent-primaryGlow", argbToCss(accent.primaryGlow))
    put("--t-accent-onPrimary", argbToCss(accent.onPrimary))
    // Semantic
    put("--t-semantic-danger", argbToCss(semantic.danger))
    put("--t-semantic-warn", argbToCss(semantic.warn))
    put("--t-semantic-success", argbToCss(semantic.success))
    put("--t-semantic-info", argbToCss(semantic.info))
    // Terminal (also useful for any text-editor pane: bg, fg, cursor, selection)
    put("--t-terminal-bg", argbToCss(terminal.bg))
    put("--t-terminal-fg", argbToCss(terminal.fg))
    put("--t-terminal-cursor", argbToCss(terminal.cursor))
    put("--t-terminal-selection", argbToCss(terminal.selection))
    put("--t-terminal-selectionText", argbToCss(terminal.selectionText))
    // Chrome
    put("--t-chrome-titlebar", argbToCss(chrome.titlebar))
    put("--t-chrome-titleText", argbToCss(chrome.titleText))
    put("--t-chrome-border", argbToCss(chrome.border))
    put("--t-chrome-shadow", argbToCss(chrome.shadow))
    put("--t-chrome-closeDot", argbToCss(chrome.closeDot))
    put("--t-chrome-minDot", argbToCss(chrome.minDot))
    put("--t-chrome-maxDot", argbToCss(chrome.maxDot))
    // Sidebar
    put("--t-sidebar-bg", argbToCss(sidebar.bg))
    put("--t-sidebar-text", argbToCss(sidebar.text))
    put("--t-sidebar-textDim", argbToCss(sidebar.textDim))
    put("--t-sidebar-activeBg", argbToCss(sidebar.activeBg))
    put("--t-sidebar-activeText", argbToCss(sidebar.activeText))
    // Bottom bar
    put("--t-bottomBar-bg", argbToCss(bottomBar.bg))
    put("--t-bottomBar-text", argbToCss(bottomBar.text))
    put("--t-bottomBar-textDim", argbToCss(bottomBar.textDim))
    put("--t-bottomBar-border", argbToCss(bottomBar.border))
    // Diff
    put("--t-diff-addBg", argbToCss(diff.addBg))
    put("--t-diff-addFg", argbToCss(diff.addFg))
    put("--t-diff-addGutter", argbToCss(diff.addGutter))
    put("--t-diff-removeBg", argbToCss(diff.removeBg))
    put("--t-diff-removeFg", argbToCss(diff.removeFg))
    put("--t-diff-removeGutter", argbToCss(diff.removeGutter))
    put("--t-diff-contextFg", argbToCss(diff.contextFg))
    // Syntax
    put("--t-syntax-keyword", argbToCss(syntax.keyword))
    put("--t-syntax-string", argbToCss(syntax.string))
    put("--t-syntax-number", argbToCss(syntax.number))
    put("--t-syntax-comment", argbToCss(syntax.comment))
    put("--t-syntax-function", argbToCss(syntax.function))
    put("--t-syntax-type", argbToCss(syntax.type))
    put("--t-syntax-operator", argbToCss(syntax.operator))
    put("--t-syntax-constant", argbToCss(syntax.constant))
}

/**
 * Returns a small map of generic CSS aliases (`--surface`, `--text-primary`,
 * etc.) suitable for stylesheets that want a shorter naming scheme than the
 * full `--t-group-token` form.
 *
 * Apps that don't need the aliases can ignore this function.
 *
 * @return map of alias name to CSS colour string
 * @see toCssVarMap
 */
fun ResolvedPalette.toCssAliasMap(): Map<String, String> = buildMap {
    put("--background", argbToCss(sidebar.bg))
    put("--surface", argbToCss(surface.raised))
    put("--bg-elevated", argbToCss(surface.overlay))
    put("--text-primary", argbToCss(text.primary))
    put("--text-secondary", argbToCss(text.secondary))
    put("--separator", argbToCss(border.subtle))
    put("--toolbar-shadow", "0 2px 8px ${argbToCss(chrome.shadow)}")
}

/**
 * Applies a map of CSS custom properties to an [HTMLElement]'s inline style.
 *
 * Apps decide where to apply: `document.documentElement` for whole-app
 * theming, a subtree root for scoped theming, or any element when
 * different sections need different themes.
 *
 * @param element the target element (e.g. `document.documentElement`)
 * @param vars map of CSS property name to value, typically from [toCssVarMap]
 */
fun applyCssVars(element: HTMLElement, vars: Map<String, String>) {
    for ((prop, value) in vars) {
        element.style.setProperty(prop, value)
    }
}

/**
 * Removes the given CSS custom properties from an element's inline style,
 * letting the inherited cascade values take over again.
 *
 * @param element the element to clear properties from
 * @param vars the property names to remove (only the keys are read; values are ignored)
 */
fun clearCssVars(element: HTMLElement, vars: Map<String, String>) {
    for (prop in vars.keys) {
        element.style.removeProperty(prop)
    }
}

/**
 * Sets `color-scheme: dark` or `color-scheme: light` on the element, which
 * lets the browser style native form controls and scrollbars to match the
 * theme. Apps typically call this on `document.documentElement` alongside
 * [applyCssVars].
 *
 * @param element the target element (e.g. `document.documentElement`)
 * @param isDark whether the current theme is the dark variant
 */
fun applyColorScheme(element: HTMLElement, isDark: Boolean) {
    element.style.setProperty("color-scheme", if (isDark) "dark" else "light")
}
