/**
 * Drop-in left/right sidebar shell components.
 *
 * Both sidebars are a fixed-width vertical column with an optional header
 * and a content slot. Apps fill the slots; the toolkit only owns the
 * layout, sizing, and theming.
 *
 * Visual styles ride on the `.dt-sidebar*` classes shipped in
 * `darkness-toolkit.css`; consumers must call `injectDarknessToolkitStyles()`
 * once at boot.
 *
 * @see SidebarSpec
 */
package se.soderbjorn.darkness.web.shell

import kotlinx.browser.document
import org.w3c.dom.HTMLElement

/**
 * Sidebar configuration shared by both [renderLeftSidebar] and [renderRightSidebar].
 *
 * @property widthPx      fixed sidebar width in pixels. Defaults to 240.
 * @property header       element shown at the top of the sidebar (label, search box, …). May be null.
 * @property content      main scrollable content of the sidebar.
 * @property visible      whether the sidebar should be rendered at all. When false, the
 *   element returned by the render functions has `display: none`.
 */
class SidebarSpec(
    val widthPx: Int = 240,
    val header: HTMLElement? = null,
    val content: HTMLElement? = null,
    val visible: Boolean = true,
)

/**
 * Builds a left-sidebar element. The bar paints with `--t-sidebar-*`
 * theme variables and has a right edge border.
 *
 * @param spec sidebar configuration
 * @return a fresh sidebar [HTMLElement]
 */
fun renderLeftSidebar(spec: SidebarSpec): HTMLElement = renderSidebar(spec, isLeft = true)

/**
 * Builds a right-sidebar element. Same as [renderLeftSidebar] but with a
 * left edge border.
 *
 * @param spec sidebar configuration
 * @return a fresh sidebar [HTMLElement]
 */
fun renderRightSidebar(spec: SidebarSpec): HTMLElement = renderSidebar(spec, isLeft = false)

private fun renderSidebar(spec: SidebarSpec, isLeft: Boolean): HTMLElement {
    val bar = document.createElement("aside") as HTMLElement
    val sideClass = if (isLeft) "dt-sidebar-left" else "dt-sidebar-right"
    val visClass = if (spec.visible) "" else " dt-hidden"
    bar.className = "dt-sidebar $sideClass$visClass"
    // Per-instance width — kept inline; no CSS variable needed since the value
    // is a one-off literal supplied by the host app.
    bar.style.width = "${spec.widthPx}px"

    spec.header?.let {
        val headerWrap = document.createElement("div") as HTMLElement
        headerWrap.className = "dt-sidebar-header"
        headerWrap.appendChild(it)
        bar.appendChild(headerWrap)
    }
    spec.content?.let {
        val contentWrap = document.createElement("div") as HTMLElement
        contentWrap.className = "dt-sidebar-content"
        contentWrap.appendChild(it)
        bar.appendChild(contentWrap)
    }
    return bar
}
