/**
 * Stylesheet exposure helper for the darkness-toolkit web components.
 *
 * Toolkit components (modal, top bar, sidebar, pane divider, theme editor,
 * …) rely on the `.dt-*` class names defined in `darkness-toolkit.css`. The
 * stylesheet is bundled both as a Kotlin string constant ([darknessToolkitCss])
 * and as a `jsMain/resources/darkness-toolkit.css` file. Apps that want the
 * default visual at boot call [injectDarknessToolkitStyles]; apps that have
 * their own stylesheet pipeline can read [darknessToolkitCss] directly and
 * inject it however they like.
 *
 * Resource-delivery choice: the CSS source is embedded into the compiled
 * Kotlin/JS bundle via a Gradle codegen step (see `build.gradle.kts`), with
 * the `.css` file in `jsMain/resources/` serving as the single source of
 * truth. This sidesteps the awkwardness of reading bundled klib resources
 * at runtime in Kotlin/JS while still letting consumers pick the file off
 * disk if they prefer.
 */
package se.soderbjorn.darkness.web

import kotlinx.browser.document
import org.w3c.dom.HTMLElement
import org.w3c.dom.HTMLStyleElement

/**
 * The toolkit stylesheet as a string. Source-of-truth lives in
 * `toolkit-web/src/jsMain/resources/darkness-toolkit.css`; the build embeds
 * it into the compiled Kotlin/JS bundle.
 */
val darknessToolkitCss: String
    get() = DARKNESS_TOOLKIT_CSS_BUNDLE

/** Marker attribute used to detect a previously-injected toolkit stylesheet. */
private const val MARKER_ATTR: String = "data-darkness-toolkit"

/**
 * Inject the darkness-toolkit stylesheet into the document so the `.dt-*`
 * class names used by toolkit components have visual styles. Idempotent —
 * subsequent calls are no-ops if the stylesheet has already been mounted
 * under [target].
 *
 * @param target the element to append the `<style>` tag to. Defaults to
 *   `document.head`. Pass a Shadow DOM root to scope toolkit styles to a
 *   subtree.
 */
fun injectDarknessToolkitStyles(target: HTMLElement = document.head as HTMLElement) {
    val existing = target.querySelector("style[$MARKER_ATTR]")
    if (existing != null) return
    val style = document.createElement("style") as HTMLStyleElement
    style.setAttribute(MARKER_ATTR, "")
    style.textContent = darknessToolkitCss
    target.appendChild(style)
}
