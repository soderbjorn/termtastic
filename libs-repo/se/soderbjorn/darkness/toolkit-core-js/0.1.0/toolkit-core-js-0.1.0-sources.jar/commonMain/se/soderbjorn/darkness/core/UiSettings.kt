/**
 * UI settings model for the Darkness theme system.
 *
 * [UiSettings] is a snapshot of the user's visual preferences (active theme,
 * appearance mode, optional per-section theme overrides). It is the wire
 * format used by every Darkness app to persist theme choices — termtastic
 * stores it server-side under `ui.settings.v1`, notegrow writes it to a
 * shared filesystem location via toolkit-store helpers.
 *
 * The JSON shape is intentionally identical to termtastic's existing
 * server blob so existing data round-trips without migration:
 *
 * ```json
 * {
 *   "theme":             "Tron",
 *   "appearance":        "Auto",
 *   "theme.sidebar":     "Verdant",
 *   "theme.terminal":    "Cyber teal",
 *   ...
 * }
 * ```
 *
 * @see ColorScheme
 * @see Appearance
 */
package se.soderbjorn.darkness.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * Snapshot of the user's visual preferences as persisted across launches.
 *
 * Used by every Darkness app — termtastic posts this to its server,
 * notegrow writes it to a shared filesystem location, mobile apps read
 * it from local storage.
 *
 * @property theme              the active theme (main colour scheme).
 * @property appearance         the user's light/dark mode preference.
 * @property sidebarTheme       optional per-section override for the sidebar.
 * @property terminalTheme      optional per-section override for terminal panes.
 * @property diffTheme          optional per-section override for diff views.
 * @property fileBrowserTheme   optional per-section override for the file browser.
 * @property tabsTheme          optional per-section override for the tab bar.
 * @property chromeTheme        optional per-section override for window chrome.
 * @property windowsTheme       optional per-section override for pane window frames.
 * @property activeTheme        optional per-section override for active indicators.
 * @property bottomBarTheme     optional per-section override for the bottom bar.
 *
 * @see toJsonString
 * @see fromJsonString
 * @see sectionTheme
 */
data class UiSettings(
    val theme: ColorScheme,
    val appearance: Appearance,
    val sidebarTheme: ColorScheme? = null,
    val terminalTheme: ColorScheme? = null,
    val diffTheme: ColorScheme? = null,
    val fileBrowserTheme: ColorScheme? = null,
    val tabsTheme: ColorScheme? = null,
    val chromeTheme: ColorScheme? = null,
    val windowsTheme: ColorScheme? = null,
    val activeTheme: ColorScheme? = null,
    val bottomBarTheme: ColorScheme? = null,
) {
    /**
     * Resolves the active colour scheme for a specific app section, falling
     * back to the global [theme] when no per-section override is set.
     *
     * Called by per-section renderers (sidebar, terminal pane, diff viewer)
     * when computing their [ResolvedPalette].
     *
     * @param section one of `"sidebar"`, `"terminal"`, `"diff"`,
     *   `"fileBrowser"`, `"tabs"`, `"chrome"`, `"windows"`, `"active"`,
     *   `"bottomBar"`. Any other value falls back to [theme].
     * @return the [ColorScheme] for that section
     */
    fun sectionTheme(section: String): ColorScheme = when (section) {
        "sidebar" -> sidebarTheme
        "terminal" -> terminalTheme
        "diff" -> diffTheme
        "fileBrowser" -> fileBrowserTheme
        "tabs" -> tabsTheme
        "chrome" -> chromeTheme
        "windows" -> windowsTheme
        "active" -> activeTheme
        "bottomBar" -> bottomBarTheme
        else -> null
    } ?: theme

    /**
     * Serialize this [UiSettings] to the canonical JSON string format
     * used across the Darkness app family.
     *
     * Only the colour-scheme **name** is written (not its colour values),
     * matching the termtastic server blob shape so server-stored data
     * round-trips without migration.
     *
     * @return a JSON object string suitable for persisting
     * @see fromJsonString
     */
    fun toJsonString(): String {
        val obj = buildJsonObject {
            put("theme", theme.name)
            put("appearance", appearance.name)
            sidebarTheme?.let { put("theme.sidebar", it.name) }
            terminalTheme?.let { put("theme.terminal", it.name) }
            diffTheme?.let { put("theme.diff", it.name) }
            fileBrowserTheme?.let { put("theme.fileBrowser", it.name) }
            tabsTheme?.let { put("theme.tabs", it.name) }
            chromeTheme?.let { put("theme.chrome", it.name) }
            windowsTheme?.let { put("theme.windows", it.name) }
            activeTheme?.let { put("theme.active", it.name) }
            bottomBarTheme?.let { put("theme.bottomBar", it.name) }
        }
        return Json.encodeToString(JsonObject.serializer(), obj)
    }

    companion object {
        /**
         * Default [UiSettings] used when no settings exist yet — the [DEFAULT_THEME_NAME]
         * theme with [Appearance.Auto].
         *
         * @return a fresh [UiSettings] with safe defaults
         */
        fun defaults(): UiSettings = UiSettings(
            theme = recommendedColorSchemes.first { it.name == DEFAULT_THEME_NAME },
            appearance = Appearance.Auto,
        )

        /**
         * Parse a JSON string into a [UiSettings].
         *
         * Unknown theme names fall back silently to [DEFAULT_THEME_NAME];
         * unknown appearance values fall back to [Appearance.Auto]. A typo
         * in stored data never crashes a client.
         *
         * Custom user-defined themes that are not in [recommendedColorSchemes]
         * cannot be resolved by this function alone — the host app should
         * pass any custom schemes via [resolveAgainst] to merge them into
         * the lookup pool.
         *
         * @param json a JSON object string in the canonical Darkness shape
         * @return the parsed [UiSettings], or [defaults] if [json] is blank or unparseable
         */
        fun fromJsonString(json: String): UiSettings {
            if (json.isBlank()) return defaults()
            val obj = runCatching {
                Json.parseToJsonElement(json) as? JsonObject
            }.getOrNull() ?: return defaults()
            return resolveAgainst(obj, recommendedColorSchemes)
        }

        /**
         * Parse a JSON object using a custom pool of colour schemes when looking
         * up names. Useful when the host app has its own user-defined schemes
         * alongside the recommended ones.
         *
         * @param obj  the parsed JSON object
         * @param pool the full list of [ColorScheme]s to look names up in
         * @return the parsed [UiSettings], or [defaults] if required fields are missing
         */
        fun resolveAgainst(obj: JsonObject, pool: List<ColorScheme>): UiSettings {
            fun string(key: String): String? =
                (obj[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
            fun scheme(key: String): ColorScheme? =
                string(key)?.let { name -> pool.firstOrNull { it.name == name } }

            val theme = scheme("theme")
                ?: pool.firstOrNull { it.name == DEFAULT_THEME_NAME }
                ?: pool.first()
            val appearance = string("appearance")
                ?.let { runCatching { Appearance.valueOf(it) }.getOrNull() }
                ?: Appearance.Auto

            return UiSettings(
                theme = theme,
                appearance = appearance,
                sidebarTheme = scheme("theme.sidebar"),
                terminalTheme = scheme("theme.terminal"),
                diffTheme = scheme("theme.diff"),
                fileBrowserTheme = scheme("theme.fileBrowser"),
                tabsTheme = scheme("theme.tabs"),
                chromeTheme = scheme("theme.chrome"),
                windowsTheme = scheme("theme.windows"),
                activeTheme = scheme("theme.active"),
                bottomBarTheme = scheme("theme.bottomBar"),
            )
        }
    }
}
