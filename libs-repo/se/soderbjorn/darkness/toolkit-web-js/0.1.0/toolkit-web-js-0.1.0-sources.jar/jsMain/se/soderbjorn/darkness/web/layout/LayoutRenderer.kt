/**
 * DOM renderer for a [PaneTree].
 *
 * Walks the tree and produces a DOM subtree of split containers and leaf
 * panes. Apps supply a [contentRenderer] callback that, given a [PaneId],
 * returns the [HTMLElement] to inject as that pane's content. A small
 * [paneHeader] callback is also supplied to build the per-pane title bar
 * (rename, action buttons, close handler) — apps can use the toolkit's
 * default in [defaultPaneHeader] or build their own.
 *
 * The renderer is **stateless** — call [render] whenever the tree changes,
 * and it produces a fresh DOM subtree. Apps can put [LayoutRenderer] inside
 * their own re-render loop, MutationObserver-driven flow, or just call
 * [render] manually after each [PaneTreeOps] operation.
 *
 * Visual styles ride on the `.dt-pane*` classes shipped in
 * `darkness-toolkit.css`; consumers must call `injectDarknessToolkitStyles()`
 * once at boot.
 *
 * @see PaneTree
 * @see PaneTreeOps
 */
package se.soderbjorn.darkness.web.layout

import kotlinx.browser.document
import org.w3c.dom.HTMLElement
import org.w3c.dom.events.MouseEvent

/**
 * Per-pane callbacks provided to [LayoutRenderer].
 *
 * @property contentRenderer  given a leaf id, returns the [HTMLElement] to
 *   inject as that pane's content. Called once per leaf per [render] call.
 * @property paneHeader       given a leaf, returns the [HTMLElement] to
 *   render as the pane's header (titlebar). Apps that don't want headers
 *   can return a zero-height div. The toolkit's [defaultPaneHeader] gives
 *   a basic title + close button.
 * @property onClose          callback invoked when the pane header's close
 *   button is clicked. Apps should call [PaneTreeOps.close] on their tree
 *   state in response.
 * @property onResize         callback invoked while the user drags a split
 *   divider. The toolkit calls this with `(targetLeafId, newFraction)` —
 *   apps should call [PaneTreeOps.resize] on their tree state.
 */
class PaneCallbacks(
    val contentRenderer: (PaneId) -> HTMLElement,
    val paneHeader: (PaneNode.Leaf) -> HTMLElement = { defaultPaneHeader(it) },
    val onClose: (PaneId) -> Unit = {},
    val onResize: (PaneId, Double) -> Unit = { _, _ -> },
)

/** Toolkit DOM class names used by the renderer (also referenced by stylesheets). */
object LayoutClassNames {
    const val ROOT = "dt-pane-root"
    const val SPLIT_H = "dt-pane-split dt-pane-split-horizontal"
    const val SPLIT_V = "dt-pane-split dt-pane-split-vertical"
    const val SPLIT_DIVIDER = "dt-pane-divider"
    const val PANE = "dt-pane"
    const val PANE_HEADER = "dt-pane-header"
    const val PANE_TITLE = "dt-pane-title"
    const val PANE_CLOSE = "dt-pane-close"
    const val PANE_CONTENT = "dt-pane-content"
    const val PANE_PLACEHOLDER = "dt-pane-placeholder"
}

/**
 * Default toolkit-provided pane header. Renders the leaf's [PaneNode.Leaf.title]
 * (or a placeholder dash) on the left and a close button on the right.
 *
 * Apps that want richer headers (rename-on-click, action menus) should pass
 * their own factory via [PaneCallbacks.paneHeader].
 *
 * @param leaf the pane to build a header for
 * @return the header [HTMLElement]
 */
fun defaultPaneHeader(leaf: PaneNode.Leaf): HTMLElement {
    val header = document.createElement("div") as HTMLElement
    header.className = LayoutClassNames.PANE_HEADER
    header.setAttribute("data-pane-id", leaf.id)

    val title = document.createElement("span") as HTMLElement
    title.className = LayoutClassNames.PANE_TITLE
    title.textContent = leaf.title ?: "—"
    header.appendChild(title)

    val close = document.createElement("button") as HTMLElement
    close.className = LayoutClassNames.PANE_CLOSE
    close.textContent = "×"
    close.setAttribute("type", "button")
    close.setAttribute("aria-label", "Close pane")
    header.appendChild(close)
    return header
}

/**
 * Stateless renderer that turns a [PaneTree] into a DOM subtree.
 *
 * Apps create one instance per layout area and call [render] every time
 * their tree state changes; the renderer wipes the container and builds
 * a fresh subtree.
 */
class LayoutRenderer(
    /** The root container that the rendered subtree is mounted into. */
    val container: HTMLElement,
    /** Per-pane content + header + close + resize callbacks. */
    val callbacks: PaneCallbacks,
) {
    init {
        if (!container.classList.contains(LayoutClassNames.ROOT)) {
            container.classList.add(LayoutClassNames.ROOT)
        }
    }

    /**
     * Renders [tree] into the container, replacing any prior content.
     *
     * @param tree the layout tree to render
     */
    fun render(tree: PaneTree) {
        // Wipe the container.
        while (container.firstChild != null) {
            container.removeChild(container.firstChild!!)
        }
        container.appendChild(buildNode(tree.root))
    }

    private fun buildNode(node: PaneNode): HTMLElement = when (node) {
        is PaneNode.Leaf -> buildLeaf(node)
        is PaneNode.Split -> buildSplit(node)
    }

    private fun buildLeaf(leaf: PaneNode.Leaf): HTMLElement {
        val pane = document.createElement("div") as HTMLElement
        pane.className = LayoutClassNames.PANE
        pane.setAttribute("data-pane-id", leaf.id)

        val header = callbacks.paneHeader(leaf)
        // Wire close button if it exists in the rendered header.
        val closeBtn = header.querySelector("." + LayoutClassNames.PANE_CLOSE) as? HTMLElement
        closeBtn?.addEventListener("click", { ev ->
            ev.preventDefault()
            ev.stopPropagation()
            callbacks.onClose(leaf.id)
        })
        pane.appendChild(header)

        val content = document.createElement("div") as HTMLElement
        content.className = LayoutClassNames.PANE_CONTENT
        val inner = callbacks.contentRenderer(leaf.id)
        content.appendChild(inner)
        pane.appendChild(content)

        return pane
    }

    private fun buildSplit(split: PaneNode.Split): HTMLElement {
        val container = document.createElement("div") as HTMLElement
        container.className = when (split.orientation) {
            SplitOrientation.Horizontal -> LayoutClassNames.SPLIT_H
            SplitOrientation.Vertical -> LayoutClassNames.SPLIT_V
        }

        val firstWrap = document.createElement("div") as HTMLElement
        firstWrap.className = "dt-pane-split-child"
        // Per-instance flex ratio bound via CSS variable; the stylesheet binds
        // flex-grow: var(--dt-pane-flex, 1).
        firstWrap.style.setProperty("--dt-pane-flex", "${split.firstFraction}")
        firstWrap.appendChild(buildNode(split.first))
        container.appendChild(firstWrap)

        val divider = buildDivider(split)
        container.appendChild(divider)

        val secondWrap = document.createElement("div") as HTMLElement
        secondWrap.className = "dt-pane-split-child"
        secondWrap.style.setProperty("--dt-pane-flex", "${1.0 - split.firstFraction}")
        secondWrap.appendChild(buildNode(split.second))
        container.appendChild(secondWrap)

        return container
    }

    private fun buildDivider(split: PaneNode.Split): HTMLElement {
        val divider = document.createElement("div") as HTMLElement
        divider.className = LayoutClassNames.SPLIT_DIVIDER
        divider.setAttribute("data-orientation", split.orientation.name)

        // Wire drag-to-resize. We pick the first leaf in the first child as
        // the "anchor" so the host app can find the relevant split via
        // PaneTreeOps.resize(targetLeafId, fraction).
        val firstLeaf = firstLeafIdOf(split.first)
        if (firstLeaf != null) {
            divider.addEventListener("mousedown", { ev ->
                ev.preventDefault()
                val mouseEv = ev as MouseEvent
                val parent = divider.parentElement as? HTMLElement ?: return@addEventListener
                val rect = parent.getBoundingClientRect()
                val total = when (split.orientation) {
                    SplitOrientation.Horizontal -> rect.width
                    SplitOrientation.Vertical -> rect.height
                }
                if (total <= 0) return@addEventListener
                val startCoord = when (split.orientation) {
                    SplitOrientation.Horizontal -> mouseEv.clientX
                    SplitOrientation.Vertical -> mouseEv.clientY
                }
                val originFraction = split.firstFraction
                val onMove: (org.w3c.dom.events.Event) -> Unit = { e ->
                    val m = e as MouseEvent
                    val delta = when (split.orientation) {
                        SplitOrientation.Horizontal -> m.clientX - startCoord
                        SplitOrientation.Vertical -> m.clientY - startCoord
                    }
                    val newFraction = (originFraction + delta / total).coerceIn(0.05, 0.95)
                    callbacks.onResize(firstLeaf, newFraction)
                }
                lateinit var onUp: (org.w3c.dom.events.Event) -> Unit
                onUp = { _ ->
                    document.removeEventListener("mousemove", onMove)
                    document.removeEventListener("mouseup", onUp)
                }
                document.addEventListener("mousemove", onMove)
                document.addEventListener("mouseup", onUp)
            })
        }
        return divider
    }

    private fun firstLeafIdOf(node: PaneNode): PaneId? = when (node) {
        is PaneNode.Leaf -> node.id
        is PaneNode.Split -> firstLeafIdOf(node.first) ?: firstLeafIdOf(node.second)
    }
}
