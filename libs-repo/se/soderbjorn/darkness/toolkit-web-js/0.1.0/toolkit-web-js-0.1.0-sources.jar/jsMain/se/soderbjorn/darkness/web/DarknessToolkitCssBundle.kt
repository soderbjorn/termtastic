package se.soderbjorn.darkness.web

internal val DARKNESS_TOOLKIT_CSS_BUNDLE: String = """/* darkness-toolkit.css
 * Shipped stylesheet for the darkness-toolkit web components.
 * Inject via injectDarknessToolkitStyles() at app boot. */

/* ── Top bar ───────────────────────────────────────────────── */
.dt-topbar {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 0 12px;
    height: 40px;
    background: var(--t-chrome-titlebar, #1e1e1e);
    color: var(--t-chrome-titleText, #e6e6e6);
    border-bottom: 1px solid var(--t-chrome-border, transparent);
    flex-shrink: 0;
}
.dt-topbar-leading {
    display: flex;
    align-items: center;
}
.dt-topbar-tabstrip {
    display: flex;
    align-items: center;
    gap: 4px;
    flex-grow: 1;
    min-width: 0;
}
.dt-topbar-tab {
    padding: 6px 12px;
    background: transparent;
    color: var(--t-text-primary, #e6e6e6);
    border: 0;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
}
.dt-topbar-tab.dt-selected {
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.06));
}
.dt-topbar-trailing {
    display: flex;
    align-items: center;
    gap: 4px;
}

/* ── Sidebar shells ───────────────────────────────────────── */
.dt-sidebar {
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    background: var(--t-sidebar-bg, #161616);
    color: var(--t-sidebar-text, #d6d6d6);
    overflow: hidden;
}
.dt-sidebar.dt-hidden {
    display: none;
}
.dt-sidebar-left {
    border-right: 1px solid var(--t-border-subtle, transparent);
}
.dt-sidebar-right {
    border-left: 1px solid var(--t-border-subtle, transparent);
}
.dt-sidebar-header {
    padding: 8px 12px;
    font-size: 12px;
    color: var(--t-sidebar-textDim, #888);
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.dt-sidebar-content {
    flex-grow: 1;
    overflow: auto;
}

/* ── Pane layout ──────────────────────────────────────────── */
.dt-pane-split {
    display: flex;
    width: 100%;
    height: 100%;
}
.dt-pane-split-horizontal {
    flex-direction: row;
}
.dt-pane-split-vertical {
    flex-direction: column;
}
.dt-pane-split > .dt-pane-split-child {
    flex-shrink: 1;
    flex-basis: 0;
    flex-grow: var(--dt-pane-flex, 1);
    min-width: 0;
    min-height: 0;
    overflow: hidden;
}
.dt-pane-divider {
    flex-shrink: 0;
    flex-grow: 0;
    background: var(--t-border-default, transparent);
    user-select: none;
}
.dt-pane-split-horizontal > .dt-pane-divider {
    cursor: col-resize;
    width: 4px;
}
.dt-pane-split-vertical > .dt-pane-divider {
    cursor: row-resize;
    height: 4px;
}

/* ── Confirm dialog ───────────────────────────────────────── */
.dt-modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.45);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
}
.dt-modal {
    background: var(--t-surface-raised, #1e1e1e);
    color: var(--t-text-primary, #e6e6e6);
    border: 1px solid var(--t-border-default, rgba(255, 255, 255, 0.12));
    border-radius: 8px;
    box-shadow: var(--t-toolbar-shadow, 0 8px 24px rgba(0, 0, 0, 0.45));
    padding: 20px 24px;
    min-width: 320px;
    max-width: 480px;
}
.dt-modal-title {
    margin: 0 0 12px 0;
    font-size: 16px;
    font-weight: 600;
}
.dt-modal-message {
    margin: 0 0 20px 0;
    color: var(--t-text-secondary, #b0b0b0);
    line-height: 1.5;
}
.dt-modal-buttons {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
}
.dt-modal-btn {
    padding: 8px 14px;
    border-radius: 4px;
    cursor: pointer;
    font-family: inherit;
}
.dt-modal-btn-cancel {
    background: transparent;
    color: var(--t-text-primary, #e6e6e6);
    border: 1px solid var(--t-border-default, rgba(255, 255, 255, 0.12));
}
.dt-modal-btn-confirm {
    background: var(--t-accent-primary, #4f8cff);
    color: var(--t-accent-onPrimary, #ffffff);
    border: 0;
    font-weight: 600;
}
.dt-modal-btn-confirm.dt-destructive {
    background: var(--t-semantic-danger, #b33a36);
}

/* ── Theme manager sidebar (right-side panel) ─────────────── */
.dt-theme-manager {
    width: 0;
    min-width: 0;
    overflow: hidden;
    flex-shrink: 0;
    background: var(--t-sidebar-bg, #252526);
    border-left: 1px solid var(--t-border-subtle, #333);
    display: flex;
    flex-direction: column;
    position: relative;
    color: var(--t-sidebar-text, #d4d4d4);
    font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", sans-serif;
    transition: width 200ms ease, min-width 200ms ease;
}
.dt-theme-manager.dt-open {
    width: 480px;
    min-width: 400px;
}
.dt-theme-manager-close {
    position: absolute;
    top: 14px;
    right: 14px;
    z-index: 2;
    appearance: none;
    background: none;
    border: none;
    color: var(--t-text-secondary, #999);
    font-size: 22px;
    cursor: pointer;
    padding: 4px 8px;
    line-height: 1;
}
.dt-theme-manager-close:hover {
    color: var(--t-text-primary, #d4d4d4);
}
.dt-theme-manager-header {
    position: relative;
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 18px 20px 12px;
    border-bottom: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.08));
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.03));
}
.dt-theme-manager-title {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: var(--t-text-primary, #d4d4d4);
    padding-right: 28px;
}
.dt-theme-manager-tabs {
    display: flex;
    gap: 4px;
}
.dt-theme-manager-tab {
    background: transparent;
    border: 1px solid transparent;
    color: var(--t-text-secondary, #c8c8c8);
    padding: 6px 14px;
    border-radius: 6px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.12s, color 0.12s, border-color 0.12s;
}
.dt-theme-manager-tab:hover {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.06));
    color: var(--t-text-primary, #d4d4d4);
}
.dt-theme-manager-tab.dt-selected {
    background: var(--t-accent-primary, #4f8cff);
    color: var(--t-accent-onPrimary, #fff);
    border-color: transparent;
}
.dt-theme-manager-body {
    flex: 1 1 auto;
    min-height: 0;
    overflow-y: auto;
    padding: 14px 18px 18px;
    display: flex;
    flex-direction: column;
}
.dt-theme-manager-back-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
}
.dt-theme-manager-back-btn {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.04));
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    color: var(--t-text-primary, #d4d4d4);
    width: 28px;
    height: 28px;
    border-radius: 6px;
    font-size: 16px;
    line-height: 1;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: background 0.12s, border-color 0.12s;
}
.dt-theme-manager-back-btn:hover {
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.08));
    border-color: var(--t-border-strong, rgba(255, 255, 255, 0.22));
}
.dt-theme-manager-back-label {
    font-size: 13px;
    font-weight: 600;
    color: var(--t-text-primary, #d4d4d4);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.dt-theme-manager-editor-host {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-height: 0;
}

/* ── Theme/scheme grid: filters, group headers, grid ──────── */
.dt-theme-manager-filters {
    display: flex;
    gap: 6px;
    margin-bottom: 12px;
    flex-wrap: wrap;
}
.dt-theme-manager-chip {
    background: transparent;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    color: var(--t-text-secondary, #c8c8c8);
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.12s, border-color 0.12s, color 0.12s;
}
.dt-theme-manager-chip:hover {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.06));
}
.dt-theme-manager-chip.dt-selected {
    background: var(--t-accent-primary, #4f8cff);
    color: var(--t-accent-onPrimary, #fff);
    border-color: transparent;
}
.dt-theme-manager-group-title {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--t-text-tertiary, #999);
    margin: 14px 0 8px;
}
.dt-theme-manager-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 10px;
    margin-bottom: 4px;
}

/* ── Theme/scheme cards ───────────────────────────────────── */
.dt-theme-card {
    position: relative;
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.02));
    border: 1.5px solid transparent;
    border-radius: 10px;
    padding: 8px 30px 8px 30px;
    cursor: pointer;
    transition: border-color 0.12s, transform 0.1s, background 0.12s;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
    min-height: 56px;
}
.dt-theme-card:hover {
    border-color: var(--t-border-strong, rgba(255, 255, 255, 0.2));
}
.dt-theme-card.dt-selected {
    border-color: var(--t-accent-primary, #4f8cff);
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.05));
}
.dt-theme-card-silhouette {
    display: inline-block;
    transform: scale(0.9);
    transform-origin: left center;
    flex-shrink: 0;
    pointer-events: none;
}
.dt-theme-card-name {
    font-size: 13px;
    color: var(--t-text-primary, #d4d4d4);
    text-align: left;
    word-break: break-word;
    display: flex;
    gap: 4px;
    align-items: center;
    justify-content: flex-start;
    flex: 1 1 auto;
    min-width: 0;
}
.dt-theme-card-star {
    position: absolute;
    top: 4px;
    left: 4px;
    background: var(--star-bg, var(--t-surface-overlay, rgba(0, 0, 0, 0.28)));
    border: none;
    color: var(--star-fg, var(--t-text-secondary, #ddd));
    font-size: 14px;
    line-height: 1;
    padding: 2px 5px;
    border-radius: 4px;
    cursor: pointer;
    transition: color 0.12s, background 0.12s;
}
.dt-theme-card-star.dt-active {
    color: var(--star-active-fg, var(--t-accent-primary, #ffc857));
}
.dt-theme-card-star:hover {
    background: var(--star-bg-hover, var(--t-surface-sunken, rgba(0, 0, 0, 0.5)));
    color: var(--star-active-fg, var(--t-accent-primary, #ffc857));
}
.dt-theme-card-kebab {
    position: absolute;
    top: 4px;
    right: 4px;
    background: var(--kebab-bg, var(--t-surface-overlay, rgba(0, 0, 0, 0.28)));
    border: none;
    color: var(--kebab-fg, var(--t-text-secondary, #ddd));
    font-size: 14px;
    line-height: 1;
    padding: 2px 8px;
    border-radius: 4px;
    cursor: pointer;
    transition: background 0.12s, color 0.12s;
}
.dt-theme-card-kebab:hover {
    background: var(--kebab-bg-hover, var(--t-surface-sunken, rgba(0, 0, 0, 0.5)));
    color: var(--kebab-fg-hover, var(--t-text-primary, #fff));
}

/* New tile (create theme/scheme) and empty-state */
.dt-new-tile {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.04));
    border: 2px dashed var(--t-border-strong, rgba(255, 255, 255, 0.18));
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 56px;
    padding: 8px;
    margin-top: 10px;
}
.dt-new-tile-plus {
    font-size: 18px;
    color: var(--t-text-tertiary, #888);
    line-height: 1;
}
.dt-new-tile-label {
    font-size: 13px;
    color: var(--t-text-secondary, #c8c8c8);
}
.dt-theme-manager-empty {
    padding: 20px 0;
    color: var(--t-text-tertiary, #888);
    font-size: 13px;
    text-align: center;
    border: 1px dashed var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    border-radius: 8px;
}

/* ── Floating menus (kebab + scheme picker) ───────────────── */
.dt-popover-menu {
    background: var(--t-surface-raised, #1e1f22);
    color: var(--t-text-primary, #d4d4d4);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    border-radius: 8px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45);
    padding: 4px;
    min-width: 200px;
    z-index: 100000;
    display: flex;
    flex-direction: column;
}
.dt-popover-menu-item {
    background: transparent;
    border: none;
    color: inherit;
    text-align: left;
    padding: 7px 10px;
    border-radius: 5px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
    font-family: inherit;
}
.dt-popover-menu-item:hover {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.08));
}

/* ── Theme editor pane ────────────────────────────────────── */
.dt-theme-editor-header {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 28px;
    margin-bottom: 16px;
}
.dt-theme-editor-preview {
    align-self: center;
    transform: scale(1.2);
    transform-origin: center left;
}
.dt-theme-editor-preview.dt-scheme-preview {
    transform: scale(1.0);
}
.dt-theme-editor-info {
    display: flex;
    flex-direction: column;
    gap: 6px;
    min-width: 0;
}
.dt-theme-editor-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--t-text-tertiary, #888);
    padding-left: 11px;
}
.dt-theme-editor-input,
.dt-theme-editor-select {
    background: var(--t-surface-base, #252526);
    color: var(--t-text-primary, #d4d4d4);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.15));
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 13px;
    font-family: inherit;
}
.dt-theme-editor-select {
    appearance: none;
    -webkit-appearance: none;
    padding-right: 34px;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8' fill='none' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M1 1.5 L6 6.5 L11 1.5'/></svg>");
    background-repeat: no-repeat;
    background-position: right 14px center;
    background-size: 10px 7px;
}
.dt-theme-editor-input:disabled,
.dt-theme-editor-select:disabled {
    opacity: 0.55;
    cursor: not-allowed;
}
.dt-theme-editor-sections {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 16px;
    padding: 12px;
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.02));
    border-radius: 8px;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.06));
}
.dt-theme-editor-section-row {
    display: grid;
    grid-template-columns: minmax(110px, 140px) 1fr;
    gap: 10px;
    align-items: center;
}
.dt-theme-editor-section-label {
    font-size: 12px;
    color: var(--t-text-secondary, #c8c8c8);
}

/* ── Per-section scheme picker ────────────────────────────── */
.dt-scheme-picker {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    background: var(--t-surface-base, #252526);
    color: var(--t-text-primary, #d4d4d4);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    border-radius: 6px;
    padding: 5px 10px;
    font-family: inherit;
    font-size: 13px;
    text-align: left;
    cursor: pointer;
    transition: border-color 0.12s, background 0.12s;
}
.dt-scheme-picker:hover:not(:disabled) {
    border-color: var(--t-border-strong, rgba(255, 255, 255, 0.25));
}
.dt-scheme-picker:disabled {
    opacity: 0.55;
    cursor: not-allowed;
}
.dt-scheme-picker-content {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1 1 auto;
    min-width: 0;
}
.dt-scheme-picker-chevron {
    flex-shrink: 0;
    color: var(--t-text-tertiary, #888);
    font-size: 10px;
    pointer-events: none;
}
.dt-scheme-row-swatch {
    flex-shrink: 0;
    width: 120px;
    display: flex;
    align-items: center;
    pointer-events: none;
}
.dt-scheme-row-label {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 13px;
    color: var(--t-text-primary, #d4d4d4);
}
.dt-scheme-row-label.dt-muted {
    color: var(--t-text-secondary, #c8c8c8);
    font-style: italic;
}
.dt-scheme-menu {
    position: fixed;
    z-index: 100000;
    max-height: 440px;
    overflow-y: auto;
    background: var(--t-surface-raised, #1e1f22);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    border-radius: 8px;
    padding: 4px;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.5);
    min-width: 300px;
}
.dt-scheme-menu-header {
    padding: 8px 10px 4px;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--t-text-tertiary, #888);
    user-select: none;
}
.dt-scheme-menu-option {
    display: flex;
    align-items: center;
    width: 100%;
    background: transparent;
    color: inherit;
    border: 1px solid transparent;
    border-radius: 6px;
    padding: 5px 8px;
    font-family: inherit;
    font-size: 13px;
    text-align: left;
    cursor: pointer;
    transition: background 0.1s, border-color 0.1s;
}
.dt-scheme-menu-option:hover {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.06));
}
.dt-scheme-menu-option.dt-selected {
    border-color: var(--t-accent-primary, #4f8cff);
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.05));
}
.dt-scheme-menu-option-content {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1 1 auto;
    min-width: 0;
}

/* ── Theme editor actions (save / revert / delete) ────────── */
.dt-theme-editor-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 14px;
    align-items: center;
}
.dt-theme-editor-btn {
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.04));
    color: var(--t-text-primary, #d4d4d4);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.15));
    border-radius: 6px;
    padding: 6px 14px;
    font-size: 13px;
    cursor: pointer;
    font-family: inherit;
    transition: background 0.12s, border-color 0.12s, opacity 0.12s;
}
.dt-theme-editor-btn:hover:not(:disabled):not(.dt-disabled) {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.08));
}
.dt-theme-editor-btn:disabled,
.dt-theme-editor-btn.dt-disabled {
    opacity: 0.4;
    cursor: not-allowed;
    filter: none;
    pointer-events: none;
}
.dt-theme-editor-btn.dt-primary {
    background: var(--t-accent-primary, #4f8cff);
    color: var(--t-accent-onPrimary, #fff);
    border-color: transparent;
}
.dt-theme-editor-btn.dt-primary:hover:not(:disabled):not(.dt-disabled) {
    background: color-mix(in oklab, var(--t-accent-primary, #4f8cff) 82%, white);
}
.dt-theme-editor-btn.dt-danger {
    color: var(--t-semantic-danger, #ff6b6b);
    border-color: rgba(255, 107, 107, 0.35);
}
.dt-theme-editor-btn.dt-danger:hover:not(:disabled):not(.dt-disabled) {
    background: rgba(255, 107, 107, 0.12);
}
.dt-theme-editor-hint {
    font-size: 12px;
    color: var(--t-text-tertiary, #888);
    font-style: italic;
    flex-basis: 100%;
}

/* ── Scheme editor (color picker dialog) ──────────────────── */
.dt-scheme-editor-fgbg {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px 16px;
    padding: 12px;
    background: var(--t-surface-raised, rgba(255, 255, 255, 0.02));
    border-radius: 8px;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.06));
    margin-bottom: 16px;
}
.dt-scheme-editor-fgbg-row {
    display: flex;
    align-items: center;
    gap: 8px;
    justify-content: space-between;
}
.dt-scheme-editor-fgbg-label {
    font-size: 12px;
    color: var(--t-text-secondary, #c8c8c8);
}
.dt-scheme-editor-fgbg-picker {
    width: 34px;
    height: 24px;
    border-radius: 4px;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    background: transparent;
    cursor: pointer;
}
.dt-scheme-editor-fgbg-picker:disabled {
    cursor: not-allowed;
    opacity: 0.5;
}
.dt-scheme-editor-overrides {
    margin-top: 8px;
}
.dt-scheme-editor-overrides-title {
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--t-text-primary, #d4d4d4);
}
.dt-scheme-editor-overrides-grid {
    display: flex;
    flex-direction: column;
    gap: 2px;
    max-height: 320px;
    overflow-y: auto;
    padding: 6px;
    background: var(--t-surface-base, #252526);
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.08));
    border-radius: 6px;
}
.dt-scheme-editor-overrides-head,
.dt-scheme-editor-overrides-row {
    display: grid;
    grid-template-columns: 1fr 72px 72px;
    gap: 8px;
    align-items: center;
    padding: 2px 4px;
    font-size: 11px;
}
.dt-scheme-editor-overrides-cell {
    display: flex;
    align-items: center;
    gap: 4px;
}
.dt-scheme-editor-overrides-cell .dt-scheme-editor-overrides-picker {
    flex: 1 1 auto;
    min-width: 0;
}
.dt-scheme-editor-overrides > .dt-theme-editor-hint {
    margin-bottom: 10px;
}
.dt-scheme-editor-overrides-head {
    color: var(--t-text-tertiary, #888);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    border-bottom: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.08));
    padding-bottom: 4px;
    margin-bottom: 4px;
}
.dt-scheme-editor-overrides-label {
    color: var(--t-text-secondary, #c8c8c8);
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 11px;
}
.dt-scheme-editor-overrides-picker {
    width: 100%;
    height: 22px;
    padding: 0;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.15));
    border-radius: 3px;
    background: transparent;
    cursor: pointer;
    position: relative;
}
.dt-scheme-editor-overrides-picker[data-set="1"] {
    border-color: var(--t-accent-primary, #4f8cff);
    box-shadow: 0 0 0 1px var(--t-accent-primary, #4f8cff);
}
.dt-scheme-editor-overrides-reset {
    background: transparent;
    border: 1px solid var(--t-border-subtle, rgba(255, 255, 255, 0.12));
    color: var(--t-text-tertiary, #888);
    border-radius: 4px;
    font-size: 14px;
    line-height: 1;
    padding: 0;
    width: 22px;
    height: 22px;
    cursor: pointer;
    justify-self: center;
    font-family: inherit;
}
.dt-scheme-editor-overrides-reset:hover:not(:disabled) {
    background: var(--t-surface-overlay, rgba(255, 255, 255, 0.06));
    color: var(--t-text-primary, #d4d4d4);
}
.dt-scheme-editor-overrides-reset.dt-inactive,
.dt-scheme-editor-overrides-reset:disabled {
    opacity: 0.3;
    cursor: default;
}

/* ── Name prompt (clone/new) ──────────────────────────────── */
.dt-name-prompt-overlay {
    position: fixed;
    inset: 0;
    z-index: 99998;
    background: rgba(0, 0, 0, 0.75);
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", sans-serif;
}
.dt-name-prompt {
    position: relative;
    background: var(--t-surface-base, #1e1e1e);
    border: 1px solid var(--t-border-default, #444);
    border-radius: 12px;
    box-shadow: 0 12px 48px rgba(0, 0, 0, 0.6);
    padding: 18px 20px 20px;
    width: 560px;
    max-width: 90vw;
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    color: var(--t-text-primary, #d4d4d4);
}
.dt-name-prompt-title {
    margin: 0 0 14px;
    font-size: 15px;
    font-weight: 600;
}
.dt-name-prompt-label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: var(--t-text-secondary, #c8c8c8);
    margin: 0 0 5px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.dt-name-prompt-input {
    display: block;
    width: 100%;
    box-sizing: border-box;
    padding: 7px 10px;
    font-size: 13px;
    font-family: inherit;
    border: 1px solid var(--t-border-default, #3c3c3c);
    border-radius: 5px;
    background: var(--t-surface-base, #252526);
    color: var(--t-text-primary, #d4d4d4);
    margin-bottom: 12px;
    outline: none;
}
.dt-name-prompt-input:focus {
    border-color: var(--t-accent-primary, #569cd6);
    box-shadow: 0 0 0 2px rgba(86, 156, 214, 0.25);
}
.dt-name-prompt-error {
    font-size: 12px;
    color: var(--t-semantic-danger, #e06c75);
    margin-bottom: 8px;
}
.dt-name-prompt-buttons {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}
.dt-name-prompt-btn {
    appearance: none;
    border: 1px solid var(--t-border-default, #3c3c3c);
    border-radius: 6px;
    padding: 7px 18px;
    font-size: 13px;
    cursor: pointer;
    font-family: inherit;
}
.dt-name-prompt-btn-cancel {
    background: var(--t-surface-base, #252526);
    color: var(--t-text-primary, #d4d4d4);
}
.dt-name-prompt-btn-cancel:hover {
    background: var(--t-surface-overlay, #2d2d30);
}
.dt-name-prompt-btn-ok {
    background: var(--t-accent-primary, #4f8cff);
    color: var(--t-accent-onPrimary, #fff);
    border-color: transparent;
}
.dt-name-prompt-btn-ok:hover {
    filter: brightness(1.12);
}
.dt-name-prompt-btn-ok:disabled {
    opacity: 0.4;
    cursor: not-allowed;
    filter: none;
}
"""
